﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project
{
    public partial class Receipt : Form
    {
        public static string N,i,b,p; 
        public Receipt()
        {
            InitializeComponent();
        }

        public Receipt(string name,string id,string brand,string price)
        {
            N = name;
            i = id;
            b = brand;
            p = price;
           // MessageBox.Show(N);
        }
        private void Receipt_Load(object sender, EventArgs e)
        {
            textBoxName.Text = N;
            textBoxId.Text = i;
            textBoxBrand.Text = b;
            textBoxPrice.Text = p;
        }
    }
}

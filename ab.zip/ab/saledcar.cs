﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace project
{
    public partial class soldcar : UserControl
    {
        public soldcar()
        {
            InitializeComponent();
        }

        private void buttonSold_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T1Q0LQ1\\sqlexpress;Initial Catalog=userinfo;Integrated Security=True");

             
            
            
            
            
            SqlDataAdapter sda = new SqlDataAdapter("Select bookedid From usertable where userphn='" + textBoxId.Text.Trim() + "' ", con);
             DataTable dt = new DataTable();
             sda.Fill(dt);
             
             if (dt.Rows[0][0].ToString() != "0")
                    {
                        string s = dt.Rows[0][0].ToString();
                        
                        MessageBox.Show("Car is Successfully Sold");

                        SqlCommand cmd1 = new SqlCommand(@"Update [dbo].[car]  SET [SaleAmount]=[SaleAmount]+1 WHERE [id] ='" + s + "'", con);
                        con.Open();
                        cmd1.ExecuteNonQuery();
                        con.Close();
                        SqlCommand cmd = new SqlCommand(@"Update [dbo].[usertable]  SET [bookedid]=0 WHERE [userphn] = '" + textBoxId.Text + "' ", con);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();



                        //try1
                        SqlDataAdapter sda1 = new SqlDataAdapter("Select username From usertable where userphn='" + textBoxId.Text.Trim() + "' ", con);
                        DataTable dt1 = new DataTable();
                        sda1.Fill(dt1);
                        string s1 = dt1.Rows[0][0].ToString();

                        //try2

                        SqlDataAdapter sda2 = new SqlDataAdapter("Select id,name,price From car where id='" + s + "' ", con);
                        DataTable dt2 = new DataTable();
                        sda2.Fill(dt2);
                        string s2 = dt2.Rows[0][0].ToString();
                        string s3 = dt2.Rows[0][1].ToString();
                        string s4 = dt2.Rows[0][2].ToString();
                       
                        // this.Hide();
                        Receipt n = new Receipt(s1,s2,s3,s4);
                        Receipt n1 = new Receipt();
                        n1.Show();
                      


                    }
                    else
                    {
                        MessageBox.Show("Booked ID Not Found");
                    }
                   
        }
    }
}
